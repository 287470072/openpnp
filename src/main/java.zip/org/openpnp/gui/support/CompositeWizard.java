package org.openpnp.gui.support;

import javax.swing.JPanel;

/**
 * Bundles one or more Wizards into a pane with tabs.
 */
public class CompositeWizard implements Wizard {

    @Override
    public void setWizardContainer(WizardContainer wizardContainer) {

    }

    @Override
    public JPanel getWizardPanel() {
        return null;
    }

    @Override
    public String getWizardName() {
        return null;
    }

}
