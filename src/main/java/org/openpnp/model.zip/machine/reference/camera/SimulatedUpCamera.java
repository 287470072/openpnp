package org.openpnp.machine.reference.camera;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.util.ConcurrentModificationException;

import org.openpnp.Translations;
import org.openpnp.gui.support.Wizard;
import org.openpnp.machine.reference.SimulationModeMachine;
import org.openpnp.machine.reference.camera.wizards.SimulatedUpCameraConfigurationWizard;
import org.openpnp.machine.reference.solutions.CameraSolutions;
import org.openpnp.model.AxesLocation;
import org.openpnp.model.Configuration;
import org.openpnp.model.Footprint;
import org.openpnp.model.Length;
import org.openpnp.model.LengthUnit;
import org.openpnp.model.Location;
import org.openpnp.model.Part;
import org.openpnp.model.Solutions;
import org.openpnp.model.Solutions.Milestone;
import org.openpnp.model.Solutions.Severity;
import org.openpnp.spi.Head;
import org.openpnp.spi.Machine;
import org.openpnp.spi.Nozzle;
import org.openpnp.spi.PropertySheetHolder;
import org.openpnp.util.Utils2D;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;


@Root
public class SimulatedUpCamera extends ReferenceCamera {
    @Attribute(required=false)
    protected int width = 640;

    @Attribute(required=false)
    protected int height = 480;
    
    @Attribute(required=false)
    private boolean simulateFocalBlur;

    @Element(required=false)
    private Location errorOffsets = new Location(LengthUnit.Millimeters);

    @Element(required=false)
    private Location simulatedLocation;

    @Element(required=false)
    private Location simulatedUnitsPerPixel;

    @Attribute(required=false)
    private boolean simulatedFlipped;

    @Element(required = false)
    private Length focalLength = new Length(6, LengthUnit.Millimeters);

    @Element(required = false)
    private Length sensorDiagonal = new Length(4.4, LengthUnit.Millimeters);


    public enum BackgroundScenario {
        Black(0x000000, 0x00FF00),
        Dark(0x222222, 0x00DD00),
        Green(0x22AA22, 0x00DD00),
        Magenta(0xAA22AA, 0x444444);

        final private int rgb;
        final private int rgbNozzleTip;
        BackgroundScenario(int rgb, int rgbNozzleTip) {
            this.rgb = rgb;
            this.rgbNozzleTip = rgbNozzleTip;
        }
        public Color getShadeColor() {
            return new Color(rgb);
        }
        Color getNozzleTipColor() {
            return new Color(rgbNozzleTip);
        }
    }

    @Attribute(required=false)
    protected BackgroundScenario backgroundScenario = BackgroundScenario.Dark;

    public SimulatedUpCamera() {
        setUnitsPerPixel(new Location(LengthUnit.Millimeters, 0.0234375D, 0.0234375D, 0, 0));
        setLooking(Looking.Up);
    }

    @Override
    public BufferedImage internalCapture() {
        if (!ensureOpen()) {
            return null;
        }
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = (Graphics2D) image.getGraphics();
        g.setColor(getBackgroundScenario().getShadeColor());
        g.fillRect(0, 0, width, height);
        AffineTransform tx = g.getTransform();
        // invert the image in Y so that Y+ is up
        g.translate(0, height);
        g.scale(1, -1);
        g.translate(width / 2, height / 2);
        g.rotate(Math.toRadians(getSimulatedLocation().getRotation()));
        if (isSimulatedFlipped()) {
            g.scale(-1.0, 1.0);
        }

        // figure out our physical viewport size
        Location phySize = getSimulatedUnitsPerPixel().convertToUnits(LengthUnit.Millimeters)
                .multiply(width, height, 0, 0);
        double phyWidth = phySize.getX()*2;
        double phyHeight = phySize.getY()*2;

        // and bounds (times two to cover perspective projection and large ICs)
        Location location = getSimulatedLocation().convertToUnits(LengthUnit.Millimeters);
        Rectangle2D.Double phyBounds = new Rectangle2D.Double(location.getX() - phyWidth,
                location.getY() - phyHeight, phyWidth*2, phyHeight*2);

        // determine if there are any nozzles within our bounds and if so render them
        Machine machine = Configuration.get()
                .getMachine();
        if (machine != null) {
            try {
                for (Head head :  machine.getHeads()) {
                    for (Nozzle nozzle : head.getNozzles()) {
                        Location l = SimulationModeMachine.getSimulatedPhysicalLocation(nozzle, getLooking(), true);
                        if (phyBounds.contains(l.getX(), l.getY())) {
                            drawNozzle(g, nozzle, l);
                        }
                    }
                }
            }
            catch (ConcurrentModificationException e) {
                // If nozzles are added/removed while enumerating them here, a ConcurrentModificationExceptions 
                // is thrown. This is not so unlikely when this camera has high fps. 
            }
        }

        g.setTransform(tx);

        SimulationModeMachine.simulateCameraExposure(this, g, width, height);

        g.dispose();

        return image;
    }

    private void drawNozzle(Graphics2D gView, Nozzle nozzle, Location l) {
        BufferedImage frame;
        Graphics2D g;
        Color bg = getBackgroundScenario().getShadeColor();
        bg = new Color(bg.getRed(), bg.getGreen(), bg.getBlue(), 0);
        if (isSimulateFocalBlur()) {
            frame = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB_PRE);
            g = frame.createGraphics();
            g.setTransform(gView.getTransform());
            // Clear with transparent background
            g.setBackground(bg);
            g.clearRect(-width/2, -height/2, width, height);
        }
        else {
           frame = null;
           g = gView;
        }

        g.setStroke(new BasicStroke(2f));
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        LengthUnit units = LengthUnit.Millimeters;
        Location unitsPerPixel = getSimulatedUnitsPerPixel().convertToUnits(units);

        boolean hasDrawn;

        // Draw the nozzle
        // Get nozzle offsets from camera
        Location offsets = l.subtractWithRotation(getSimulatedLocation());

        // Create a nozzle shape
        if (fillShape(g, new Ellipse2D.Double(-0.5, -0.5, 1, 1), getBackgroundScenario().getNozzleTipColor(), unitsPerPixel, offsets, false)) {
            fillShape(g, new Ellipse2D.Double(-0.1, -0.1, 0.2, 0.2), new Color(32, 32, 32), unitsPerPixel, offsets, false);
            if (frame != null) {
                blurObjectIntoView(gView, frame, nozzle, l);

                // Clear with transparent background
                g.setBackground(bg);
                g.clearRect(-width/2, -height/2, width, height);
            }

            // Draw the part
            Part part = nozzle.getPart();
            if (part == null) {
                return;
            }

            org.openpnp.model.Package pkg = part.getPackage();
            Footprint footprint = pkg.getFootprint();
            if (footprint == null) {
                return;
            }

            Length u = new Length(1, footprint.getUnits())
                    .convertToUnits(unitsPerPixel.getUnits());
            double unitScale = u.getValue();

            // Account for the part height.
            double partHeightMm = Math.abs(part.getHeight().convertToUnits(LengthUnit.Millimeters).getValue());
            if (partHeightMm == 0) {
                // Just simulate something.
                partHeightMm = 1.0;
            }
            Location partUndersideLocation = l.subtract(new Location(LengthUnit.Millimeters, 
                    0, 0, partHeightMm, 0));
            offsets = partUndersideLocation.subtractWithRotation(getSimulatedLocation());

            // Transform footprint shapes to right-hand coordinate system.
            Shape bodyShape = footprint.getBodyShape();
            Shape padsShape = footprint.getPadsShape();
            AffineTransform txShape = new AffineTransform();
            txShape.scale(unitScale, unitScale);
            padsShape = txShape.createTransformedShape(padsShape);
            bodyShape = txShape.createTransformedShape(bodyShape);

            // First draw the body in dark grey.
            fillShape(g, bodyShape, new Color(60, 60, 60), unitsPerPixel, offsets, true);

            // Then draw the pads in white
            fillShape(g, padsShape, Color.white, unitsPerPixel, offsets, true);

            if (frame != null) {
                blurObjectIntoView(gView, frame, nozzle, 
                        partUndersideLocation);

                g.dispose();
            }
        }
        else {
            if (frame != null) {
                g.dispose();
            }
        }
    }

    protected void blurObjectIntoView(Graphics2D gView, BufferedImage frame, Nozzle nozzle, Location l) {
        // Blur according to Z coordinate
        AffineTransform tx = gView.getTransform();
        gView.setTransform(new AffineTransform());
        double distanceMm = Math.abs(l.subtract(getSimulatedLocation()).convertToUnits(LengthUnit.Millimeters).getZ());
        final double bokeh = 0.01/getSimulatedUnitsPerPixel().convertToUnits(LengthUnit.Millimeters).getX();
        double radius = Math.min(distanceMm*bokeh, 5); // Be reasonable.
        ConvolveOp op = null;
        if (radius > 0.01) {
            int size = (int)Math.ceil(radius) * 2 + 1;
            float[] data = new float[size * size];
            double sum = 0;
            int num = 0;
            for (int i = 0; i < data.length; i++) {
                double x = i/size - size/2.0 + 0.5;
                double y = i%size - size/2.0 + 0.5;
                double r = Math.sqrt(x*x+y*y);
                // rough approximation
                float weight = (float) Math.max(0, Math.min(1, radius + 1 - r));
                data[i] = weight;
                sum += weight;
                if (weight > 0) {
                    num++;
                }
            }
            if (num > 1) {
                for (int i = 0; i < data.length; i++) {
                    data[i] /= sum;
                }

                Kernel kernel = new Kernel(size, size, data);
                op = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
            }
        }
        gView.drawImage(frame, op, 0, 0);
        gView.setTransform(tx);
    }

    private boolean fillShape(Graphics2D g, Shape shape, Color color, Location unitsPerPixel, Location offsets, boolean addError) {
        AffineTransform tx = new AffineTransform();
        double cameraViewDiagonal = Math.sqrt(Math.pow(unitsPerPixel.getX()*width, 2) + Math.pow(unitsPerPixel.getY()*height, 2));
        double sensorDiagonal = getSensorDiagonal().convertToUnits(AxesLocation.getUnits()).getValue();
        double focalLength = getFocalLength().convertToUnits(AxesLocation.getUnits()).getValue();
        double cameraDistance = focalLength*cameraViewDiagonal/sensorDiagonal;
        double zDistance = cameraDistance + offsets.getZ();
        double perspective = zDistance/cameraDistance;
        if (perspective <= 2) { // Limit the perspective projection "frustrum" to twice the view size. 
            Location unitsPerPixelAtZ = unitsPerPixel.multiply(perspective);
                    
            // Scale to pixels
            tx.scale(1.0 / unitsPerPixelAtZ.getX(), 1.0 / unitsPerPixelAtZ.getY());
            // Translate and rotate to offsets
            tx.translate(offsets.getX(), offsets.getY());
            tx.rotate(Math.toRadians(Utils2D.normalizeAngle(offsets.getRotation())));
            if (addError) {
                // Translate and rotate to error offsets
                tx.translate(errorOffsets.getX(), errorOffsets.getY());
                tx.rotate(Math.toRadians(Utils2D.normalizeAngle(errorOffsets.getRotation())));
            }
            // Transform
            shape = tx.createTransformedShape(shape);
            // Draw
            double shade = Math.pow(perspective, 2); 
            Color colorShade = new Color(
                    (int)Math.min(255, color.getRed()/shade), 
                    (int)Math.min(255, color.getGreen()/shade), 
                    (int)Math.min(255, color.getBlue()/shade));
            g.setColor(colorShade);
            g.fill(shape);
            return true;
        }
        return false;
    }

    public int getViewWidth() {
        return width;
    }

    public void setViewWidth(int width) {
        this.width = width;
    }

    public int getViewHeight() {
        return height;
    }

    public void setViewHeight(int height) {
        this.height = height;
    }

    public Location getSimulatedLocation() {
        if (simulatedLocation == null) {
            simulatedLocation = this.getLocation();
        }
        return simulatedLocation;
    }

    public void setSimulatedLocation(Location simulatedLocation) {
        this.simulatedLocation = simulatedLocation;
    }

    public Location getSimulatedUnitsPerPixel() {
        if (simulatedUnitsPerPixel == null) {
            simulatedUnitsPerPixel = getUnitsPerPixel();
        }
        return simulatedUnitsPerPixel;
    }

    public void setSimulatedUnitsPerPixel(Location simulatedUnitsPerPixel) {
        this.simulatedUnitsPerPixel = simulatedUnitsPerPixel;
    }

    public boolean isSimulatedFlipped() {
        return simulatedFlipped;
    }

    public void setSimulatedFlipped(boolean simulatedFlipped) {
        this.simulatedFlipped = simulatedFlipped;
    }

    public Length getFocalLength() {
        return focalLength;
    }

    public void setFocalLength(Length focalLength) {
        this.focalLength = focalLength;
    }

    public Length getSensorDiagonal() {
        return sensorDiagonal;
    }

    public void setSensorDiagonal(Length sensorDiagonal) {
        this.sensorDiagonal = sensorDiagonal;
    }

    public boolean isSimulateFocalBlur() {
        return simulateFocalBlur;
    }

    public void setSimulateFocalBlur(boolean simulateFocalBlur) {
        this.simulateFocalBlur = simulateFocalBlur;
    }

    public Location getErrorOffsets() {
        return errorOffsets;
    }

    public void setErrorOffsets(Location errorOffsets) {
        this.errorOffsets = errorOffsets;
    }

    public BackgroundScenario getBackgroundScenario() {
        return backgroundScenario;
    }

    public void setBackgroundScenario(BackgroundScenario backgroundScenario) {
        this.backgroundScenario = backgroundScenario;
    }

    @Override
    public Wizard getConfigurationWizard() {
        return new SimulatedUpCameraConfigurationWizard(this);
    }

    @Override
    public String getPropertySheetHolderTitle() {
        return getClass().getSimpleName() + " " + getName();
    }

    @Override
    public PropertySheetHolder[] getChildPropertySheetHolders() {
        return null;
    }


    @Override
    public void findIssues(Solutions solutions) {
        super.findIssues(solutions);
        if (solutions.isTargeting(Milestone.Connect)) {
            solutions.add(new Solutions.Issue(
                    this,
                    Translations.getString("SimulatedUpCamera.Issue"), //$NON-NLS-1$
                    Translations.getString("SimulatedUpCamera.Solution"), //$NON-NLS-1$
                    Severity.Fundamental,
                    "https://github.com/openpnp/openpnp/wiki/OpenPnpCaptureCamera") {

                @Override
                public void setState(Solutions.State state) throws Exception {
                    if (state == Solutions.State.Solved) {
                        OpenPnpCaptureCamera camera = CameraSolutions.createReplacementCamera(SimulatedUpCamera.this);
                        CameraSolutions.replaceCamera(camera);
                    }
                    else if (getState() == Solutions.State.Solved) {
                        // Place the old one back (from the captured SimulatedUpCamera.this).
                        CameraSolutions.replaceCamera(SimulatedUpCamera.this);
                    }
                    super.setState(state);
                }
            });
        }
    }
}
